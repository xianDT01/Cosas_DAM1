package conexioncompany;

import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;

public class ConexionCompany {

    public static void main(String[] args) {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            String connectionStr = "jdbc:mysql://127.0.0.1:3306/company?user=root&password=abc123.";
            connection = DriverManager.getConnection(connectionStr);
            // Ejemplo de consulta
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT empno, ename from emp");
            while (rs.next()) {
                int x = rs.getInt("empno");
                String s = rs.getString("ename");
                System.out.println(x + " " + s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
