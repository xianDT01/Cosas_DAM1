
package videoclub;

import controlador.Pelicula_Ctrl;

public class Videoclub {

    public static void main(String[] args) {
        Pelicula_Ctrl peliCtrl = new Pelicula_Ctrl();
    }
    
}
