package controlador;

import modelo.Pelicula_DB;
import vista.Pelicula_Vista;

public class Pelicula_Ctrl {
    Pelicula_Vista peliVista = new Pelicula_Vista();
    Pelicula_DB peliDB;
    
    public Pelicula_Ctrl(){
        listarPeliculas();
        peliVista.setVisible(true);
    }

    /**
     * Muestra los registros en un JTable
     * 
     * Se usa una matriz TEMPORAL para recoger los datos del modelo y 
     * pasarselos a la vista.
     */
    public void listarPeliculas() {
        String[][] bufferTabla= null;

        peliDB = new Pelicula_DB();
        bufferTabla = peliDB.leerVarios();       // Trae la matriz
        peliVista.pintarTabla(bufferTabla);      // Envía la matriz
        peliVista.setVisible(true);
    }
    
}
