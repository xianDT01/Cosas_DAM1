

package modelo;

import java.sql.*;
import javax.swing.JOptionPane;


public class Pelicula_DB {
    Connection con;

    public Pelicula_DB() {
        Conexion conexion = new Conexion();
        con = new Conexion().getConexion();
    }
    
    /**
     * Lectura de registros de la tabla de Peliculaes
     *
     * @return un array de Strings con todos los pelies de la tabla
     */
    public String[][] leerVarios() {
        Statement stmt;
        ResultSet rs = null;

        // Tamaño de la matriz
        int filas = 0;      // este valor lo buscamos después de leer
        int cols = 4;

        try {
            String sql = "SELECT id, titulo, actor, tematica FROM peliculas ";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            rs.last();                  // Buscar último elemento
            filas = rs.getRow();        // Coger la posición del elemento
            rs.first();                 // Volver el puntero al inicio

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error LEYENDO Peliculaes " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }

        // El resultado de la lectura RS lo pasamos a matriz de String
        String[][] bufferTabla = convertirRS_Array(rs, filas, cols);

        return bufferTabla;
    }
    




    

    /**
     * Convierte un registro de la BD a Objeto (Pelicula)
     *
     * @param rs
     * @return
     */
    public Pelicula convertirRS(ResultSet rs) {
        Pelicula peli = new Pelicula();
        try {
            peli.setId(Integer.parseInt(rs.getString("id")));
            peli.setTitulo(rs.getString("nombre"));
            peli.setActor(rs.getString("posicion"));
            peli.setTematica(rs.getInt("tematica"));
            
            if (rs.getInt("disponible") == 0){
                peli.setDisponible(false);
            } else {
                peli.setDisponible(true);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error Convirtiendo RS a peli " + ex.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
        return peli;
    }

    /**
     * Convierte el resultado de una lectura con varios registros a Matriz
     *
     * @param rs, todas las filas leídas... Ojo YA VIENE POSICIONADO EN FIRST
     * @param filas, para inicializar la matriz
     * @param cols, para inicializar la matriz
     * @return una matriz de Strings
     */
    public String[][] convertirRS_Array(ResultSet rs, int filas, int cols) {
        String[][] bufferTabla = bufferTabla = new String[filas][cols];
        try {
            int i = 0;
            do {
                for (int j = 0; j < cols; j++) {
                    bufferTabla[i][j] = rs.getString(j + 1);
                }
                i++;
            } while (rs.next());

        } catch (SQLException e) {
            System.out.println("Error " + e.getMessage());
        }
        return bufferTabla;
    }
}
