package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Luis
 * Gestionamos la conexión
 * Definimos parámetros necesarios para construir una conexión
 * creamos el método getConexion() que devuelve un objeto conexión
*/
public class Conexion {

    String bd = "videoclub";
    String user = "root";
    String password = "eureka";
    String url = "jdbc:mysql://localhost:3306/" + bd+"?serverTimezone=UTC";
    String drive =  "com.mysql.cj.jdbc.Driver";
    Connection con = null;

    public Connection getConexion() {
        try {
            Class.forName(drive);
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException ex) {
            System.out.println("Error, falta controlador " + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Error de conexión " + ex.getMessage());
        }
        return con;
    }

}
