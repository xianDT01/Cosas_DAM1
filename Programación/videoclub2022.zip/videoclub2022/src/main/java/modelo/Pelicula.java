
package modelo;

public class Pelicula {
    private int id;
    private String titulo;
    private String actor;
    private int tematica;
    private String guion;
    private boolean disponible;
    
    public Pelicula(int id, String titulo, String actor, int tematica, String guion, boolean disponible) {
        this.id = id;
        this.titulo = titulo;
        this.actor = actor;
        this.tematica = tematica;
        this.guion = guion;
        this.disponible = disponible;
    }

    public Pelicula() {
    }
   
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public int getTematica() {
        return tematica;
    }

    public void setTematica(int tematica) {
        this.tematica = tematica;
    }

    public String getGuion() {
        return guion;
    }

    public void setGuion(String guion) {
        this.guion = guion;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

   
    
    
}
